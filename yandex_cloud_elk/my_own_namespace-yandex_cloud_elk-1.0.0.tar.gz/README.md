# Ansible Collection - my_own_namespace.yandex_cloud_elk

Documentation for the collection. This collection contain ansible role and single task playbook. 
This module implement file creating on various operating system in path specified on default var file.

Created by Sharafukov Ilshat for Netology School.
